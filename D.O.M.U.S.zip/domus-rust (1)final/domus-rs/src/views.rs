//! Telas (HTML renderizado no servidor, 100% Rust, sem JavaScript).

use crate::store::*;

pub const TYPES: [&str; 7] = ["Aspirador", "Passa-pano", "Cozinha", "Lavanderia", "Drone", "Lava louças", "Outro"];
pub const CATS: [&str; 4] = ["Limpeza", "Cozinha", "Lavanderia", "Fora da casa"];
pub const HOUSE_ROOMS: [&str; 5] = ["Sala", "Cozinha", "Quarto 1", "Quarto 2", "Banheiro"];
/// (rótulo do botão, status, texto da tarefa)
pub const QUICK_TASKS: [(&str, &str); 4] = [
    ("Aspirar cômodo", "Aspirando o cômodo"),
    ("Limpeza completa", "Limpeza completa"),
    ("Ir à um cômodo", "Indo ao cômodo"),
    ("Mapear ambiente", "Mapeando ambiente"),
];

pub fn esc(s: &str) -> String {
    let mut o = String::with_capacity(s.len());
    for c in s.chars() {
        match c {
            '&' => o.push_str("&amp;"),
            '<' => o.push_str("&lt;"),
            '>' => o.push_str("&gt;"),
            '"' => o.push_str("&quot;"),
            '\'' => o.push_str("&#39;"),
            _ => o.push(c),
        }
    }
    o
}

/* ───────────── Ícones ───────────── */
pub fn ico_c(name: &str, cls: &str) -> String {
    let p = match name {
        "home" => r##"<path d="M3 11l9-8 9 8"/><path d="M5 10v10h5v-6h4v6h5V10"/>"##,
        "rooms" => r##"<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 12h9M12 3v18"/>"##,
        "fleet" => r##"<rect x="5" y="8" width="14" height="10" rx="3"/><path d="M12 4v4M9 13h.01M15 13h.01M3 12v3M21 12v3"/>"##,
        "missions" => r##"<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M8 3v4M16 3v4M3 10h18"/>"##,
        "user" => r##"<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>"##,
        "back" => r##"<path d="M15 5l-7 7 7 7"/>"##,
        "chevR" => r##"<path d="M9 5l7 7-7 7"/>"##,
        "chevD" => r##"<path d="M5 9l7 7 7-7"/>"##,
        "edit" => r##"<path d="M4 20h4L19 9l-4-4L4 16z"/>"##,
        "mail" => r##"<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/>"##,
        "warn" => r##"<path d="M12 3l10 18H2z"/><path d="M12 10v5M12 18h.01"/>"##,
        "check" => r##"<path d="M5 12l5 5 9-10"/>"##,
        "shield" => r##"<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/>"##,
        "tool" => r##"<path d="M14 6a4 4 0 005 5l-9 9a2 2 0 01-3-3l9-9a4 4 0 00-2-2z"/>"##,
        "fam" => r##"<circle cx="9" cy="8" r="3"/><circle cx="17" cy="9" r="2.5"/><path d="M3 20c0-3 3-5 6-5s6 2 6 5M16 15c3 0 5 1.5 5 4"/>"##,
        "battery" => r##"<rect x="2" y="8" width="18" height="9" rx="2"/><path d="M22 11v3"/>"##,
        "search" => r##"<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>"##,
        "fp" => r##"<path d="M12 11v4a6 6 0 01-1 3M8 14a4 4 0 018 0v1a10 10 0 01-1.5 5M5 12a7 7 0 0114 0v2M3 9a10 10 0 0118 0M8 20c.8-1.5 1-3 1-5"/>"##,
        _ => "",
    };
    format!(r##"<svg class="i {}" viewBox="0 0 24 24" aria-hidden="true">{}</svg>"##, cls, p)
}
pub fn ico(name: &str) -> String { ico_c(name, "") }

const ROBOT_SVG: &str = r##"<svg viewBox="0 0 80 80"><circle cx="40" cy="40" r="32" fill="#2a2f36"/><circle cx="40" cy="40" r="22" fill="#3a424c"/><circle cx="40" cy="40" r="7" fill="#7fd3ff"/><circle cx="26" cy="26" r="3" fill="#6fe38b"/></svg>"##;
const GOOGLE_SVG: &str = r##"<svg viewBox="0 0 24 24"><path fill="#EA4335" d="M12 10.2v3.9h5.5c-.2 1.3-1.6 3.9-5.5 3.9a6.1 6.1 0 010-12.2c1.9 0 3.1.8 3.8 1.5l2.6-2.5A9.6 9.6 0 0012 2.4a9.6 9.6 0 100 19.2c5.5 0 9.2-3.9 9.2-9.4 0-.6-.1-1.1-.2-2z"/></svg>"##;

/* ───────────── Layout ───────────── */
const NAV: [(&str, &str, &str); 5] = [
    ("home", "/home", "Casa"),
    ("rooms", "/comodos", "Cômodos"),
    ("fleet", "/frota", "Frota"),
    ("missions", "/missoes", "Missões"),
    ("user", "/perfil", "Perfil"),
];

pub fn page(title: &str, inner: &str, nav: Option<&str>) -> String {
    let nav_html = match nav {
        Some(active) => {
            let items: String = NAV
                .iter()
                .map(|(i, href, label)| {
                    format!(
                        r##"<a href="{}" class="{}" aria-label="{}">{}<span>{}</span></a>"##,
                        href,
                        if *href == active { "active" } else { "" },
                        label,
                        ico(i),
                        label
                    )
                })
                .collect();
            format!(r##"<nav class="bottom-nav" aria-label="Navegação principal">{}</nav>"##, items)
        }
        None => String::new(),
    };
    format!(
        r##"<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"><meta name="theme-color" content="#5C9BCB"><title>{} – D.O.M.U.S.</title><link rel="stylesheet" href="/static/styles.css"><link rel="stylesheet" href="/static/extra.css"></head><body><div class="stage"><div class="phone"><main class="screen{}">{}</main>{}<!--FLASH--></div></div></body></html>"##,
        esc(title),
        if nav.is_some() { " has-nav" } else { "" },
        inner,
        nav_html
    )
}

fn header(title: &str, back: Option<&str>, left: bool, right: &str) -> String {
    let l = match back {
        Some(h) => format!(r##"<a class="hbtn" href="{}" aria-label="Voltar">{}</a>"##, h, ico("back")),
        None => format!(r##"<a class="hbtn" href="/home" aria-label="Início">{}</a>"##, ico("home")),
    };
    let r = if right.is_empty() { r##"<span class="spacer"></span>"## } else { right };
    format!(r##"<header class="app-header{}">{}<h1>{}</h1>{}</header>"##, if left { " left" } else { "" }, l, esc(title), r)
}

fn br_date(iso: &str) -> String {
    let p: Vec<&str> = iso.split('-').collect();
    if p.len() == 3 { format!("{}/{}/{}", p[2], p[1], p[0]) } else { iso.to_string() }
}

/* ───────────── Autenticação ───────────── */
pub fn login() -> String {
    page(
        "Entrar",
        &format!(
            r##"<section class="login"><h1>D.O.M.U.S</h1><p class="sub">Sua casa na sua mão</p>
<div class="avatar" style="width:76px;height:76px">{user}</div>
<p style="font-size:12px;margin-top:10px">Use sua Biometria</p>
<form method="post" action="/biometria"><button class="fp-btn" aria-label="Entrar com biometria">{fp}</button></form>
<div class="or">ou</div>
<a class="btn email-btn" href="/entrar" style="display:flex;gap:8px;justify-content:center;align-items:center;text-decoration:none">{mail} Entrar com E-mail</a>
<p class="bottom">Não tem conta? <a href="/cadastro">Crie uma aqui</a></p></section>"##,
            user = ico("user"),
            fp = ico("fp"),
            mail = ico("mail")
        ),
        None,
    )
}

fn auth_shell(title: &str, body: &str) -> String {
    page(
        title,
        &format!(
            r##"<div class="auth-wrap"><div class="auth-top"><div class="brand"><span>Smart Fleet Manager</span>{}</div><h2>{}</h2></div><div class="auth-card">{}</div></div>"##,
            ico("chevD"),
            esc(title),
            body
        ),
        None,
    )
}

pub fn email_login() -> String {
    auth_shell(
        "Entrar com Email",
        &format!(
            r##"<form method="post" action="/entrar">
<div class="field"><input name="email" type="email" placeholder="E-mail" autocomplete="username" required><span class="ico">{mail}</span></div>
<div class="field"><input name="senha" type="password" placeholder="Senha" autocomplete="current-password" required></div>
<p style="text-align:right;margin:-6px 0 14px"><a class="link-btn" href="/redefinir">Esqueci a senha</a></p>
<button class="btn" style="width:60%;display:block;margin:0 auto">Login</button></form>
<p style="text-align:center;margin-top:16px;font-size:12px"><a class="link-btn" href="/login">← Voltar</a> · <a class="link-btn" href="/cadastro">Criar conta</a></p>
<p style="text-align:center;margin-top:14px;font-size:11px;color:var(--muted)">Demo: robertao@email.com / domus123</p>"##,
            mail = ico("mail")
        ),
    )
}

pub fn register() -> String {
    auth_shell(
        "Cadastro",
        &format!(
            r##"<form method="post" action="/cadastro">
<div class="field"><input name="email" type="email" placeholder="E-mail" required><span class="ico">{mail}</span></div>
<div class="field"><input name="senha" type="password" placeholder="Senha (mín. 6 caracteres)" minlength="6" autocomplete="new-password" required></div>
<div class="field"><input name="confirmar" type="password" placeholder="Confirmar senha" minlength="6" autocomplete="new-password" required></div>
<button class="btn" style="width:60%;display:block;margin:0 auto">Finalizar</button></form>
<div class="divider">ou</div>
<div class="social"><a class="soc" href="/cadastro" aria-label="Google (indisponível)">{g}</a></div>
<p style="text-align:center;margin-top:8px;font-size:10px;color:var(--muted)">Login social ainda não configurado</p>
<p style="text-align:center;margin-top:12px;font-size:12px"><a class="link-btn" href="/login">← Voltar</a></p>"##,
            mail = ico("mail"),
            g = GOOGLE_SVG
        ),
    )
}

pub fn reset() -> String {
    auth_shell(
        "Redefinir Senha",
        r##"<form method="post" action="/redefinir">
<div class="field"><input name="email" type="email" placeholder="Email" required></div>
<div class="field"><input name="confirmar" type="email" placeholder="Confirmar email" required></div>
<button class="btn" style="width:60%;display:block;margin:6px auto 0">Redefinir</button></form>
<p style="text-align:center;margin-top:16px;font-size:12px"><a class="link-btn" href="/entrar">← Voltar</a></p>"##,
    )
}

/* ───────────── Home ───────────── */
fn robot_row(r: &Robot) -> String {
    let bar = if r.status == "working" || r.status == "paused" {
        format!(r##"<span class="progress"><i style="width:{p}%"></i></span><span class="pct">{p}%</span>"##, p = r.progress.min(100))
    } else {
        String::new()
    };
    format!(
        r##"<a class="robot-row" href="/robo/{}"><span class="robot-ico s-{}"></span><span class="robot-info"><b>{}</b><small>{}</small></span>{}</a>"##,
        r.id, esc(&r.status), esc(&r.task), esc(&r.name), bar
    )
}

pub fn home(db: &Db, u: &User) -> String {
    let greet = match local_hour() {
        5..=11 => "Bom dia",
        12..=17 => "Boa tarde",
        _ => "Boa noite",
    };
    let sec = db.alerts.iter().filter(|a| a.level == "crit" || a.level == "warn").count();
    let man = db.maints.iter().filter(|m| m.status == "open" && (m.level == "warn" || m.level == "crit")).count();
    let working = db.active_robots().filter(|r| r.status == "working").count();
    let rows: String = db.active_robots().map(robot_row).collect();
    let rows = if rows.is_empty() { r##"<p class="empty">Nenhum robô cadastrado</p>"##.to_string() } else { rows };
    let first = u.name.split_whitespace().next().unwrap_or("");
    page(
        "Casa",
        &format!(
            r##"{header}<div class="content">
<div class="chips">
<a class="chip sec" href="/alertas">{w}<span><b>Alertas de segurança</b><small>{sec} ativos · ver detalhes</small></span></a>
<a class="chip man" href="/alertas?tab=man">{t}<span><b>Aviso de manutenção</b><small>{man} pendentes</small></span></a>
</div>
<p class="section-title">Acontecendo agora</p><div class="panel">{rows}</div></div>
<form class="stop-wrap" method="post" action="/parar-todos"><button class="btn danger" {dis}>Parar todos</button></form>"##,
            header = header(&format!("{}, {}!", greet, first), None, true, ""),
            w = ico("warn"),
            t = ico("tool"),
            sec = sec,
            man = man,
            rows = rows,
            dis = if working == 0 { "disabled" } else { "" }
        ),
        Some("/home"),
    )
}

/* ───────────── Alertas e manutenção ───────────── */
fn lvl_icon(level: &str) -> &'static str {
    match level {
        "ok" => "check",
        "info" => "shield",
        _ => "warn",
    }
}

pub fn alerts(db: &Db, tab_man: bool) -> String {
    let tabs = format!(
        r##"<div class="tabs"><a href="/alertas" class="{}">Alertas</a><a href="/alertas?tab=man" class="{}">Manutenção</a></div>"##,
        if tab_man { "" } else { "active" },
        if tab_man { "active" } else { "" }
    );
    let body = if !tab_man {
        let items: String = db
            .alerts
            .iter()
            .map(|a| {
                format!(
                    r##"<div class="alert-card"><span class="lvl {l}">{i}</span><span class="t"><b>{t}</b><small>{x}</small></span><time>{tm}</time></div>"##,
                    l = esc(&a.level), i = ico(lvl_icon(&a.level)), t = esc(&a.title), x = esc(&a.text), tm = esc(&a.time)
                )
            })
            .collect();
        format!(r##"<p class="section-title">Alertas de segurança</p><div class="panel">{}</div>"##, items)
    } else {
        let items: String = db
            .maints
            .iter()
            .filter(|m| m.status == "open")
            .filter_map(|m| db.robots.iter().find(|r| r.id == m.robot_id).map(|r| (m, r)))
            .map(|(m, r)| {
                format!(
                    r##"<label class="alert-card pick"><input class="sr" type="radio" name="id" value="{id}"><span class="lvl {l}">{i}</span><span class="t"><b>{n}</b><small>{k}</small><small class="note-{l}">{note}</small></span><span class="radio"></span></label>"##,
                    id = m.id, l = esc(&m.level), i = ico(lvl_icon(&m.level)), n = esc(&r.name), k = esc(&r.kind), note = esc(&m.note)
                )
            })
            .collect();
        let items = if items.is_empty() { r##"<p class="empty">Nenhuma manutenção pendente</p>"##.to_string() } else { items };
        format!(
            r##"<p class="section-title">Manutenção preditiva</p><form method="post"><div class="panel">{}</div>
<div class="btn-row"><button class="btn sm" formaction="/manutencao/agendar">Agendar reparo</button><button class="btn sm" formaction="/manutencao/retirar">Tirar da frota</button></div></form>"##,
            items
        )
    };
    page("Alertas e manutenção", &format!(r##"{}<div class="content">{}{}</div>"##, header("Alertas e manutenção", None, false, ""), tabs, body), Some("/home"))
}

/* ───────────── Perfil e convites ───────────── */
pub fn profile(db: &Db, u: &User) -> String {
    let members: String = db
        .family
        .iter()
        .map(|f| format!(r##"<div class="member"><span class="avatar" style="width:20px;height:20px">{}</span>{}</div>"##, ico("user"), esc(&f.name)))
        .collect();
    page(
        "Perfil",
        &format!(
            r##"<header class="app-header"><h1 style="text-align:left">Perfil</h1><span class="link">{house} {chev}</span></header>
<div class="content" style="background:#fff">
<div class="profile-head"><div class="avatar" style="width:64px;height:64px">{user}</div><h2>{name}</h2></div>
<details class="edit"><summary class="row-btn">{email} {edit}</summary>
<form method="post" action="/perfil/email" class="inline"><div class="field"><input name="email" type="email" value="{email}" required></div><button class="btn sm">Salvar e-mail</button></form></details>
<form method="post" action="/perfil/biometria"><button class="row-btn">{bio}+ Nova Biometria</button></form>
<div class="family"><h3>{fam} Família</h3>{members}<a class="add" href="/convidar">+ Adicionar membro</a></div>
<form method="post" action="/sair"><button class="btn light" style="margin-top:18px">Sair da conta</button></form></div>"##,
            house = esc(&u.house),
            chev = ico("chevR"),
            user = ico("user"),
            name = esc(&u.name),
            email = esc(&u.email),
            edit = ico("edit"),
            bio = if u.biometric { "✓ Biometria cadastrada · " } else { "" },
            fam = ico("fam"),
            members = members
        ),
        Some("/perfil"),
    )
}

/// QR visual determinístico (decorativo, não escaneável) com marcadores de canto.
pub fn qr_svg(text: &str) -> String {
    let n: i32 = 25;
    let mut h: u32 = 2_166_136_261;
    for b in text.bytes() {
        h ^= b as u32;
        h = h.wrapping_mul(16_777_619);
    }
    let mut rnd = move || -> bool {
        h = (h ^ (h >> 15)).wrapping_mul(2_246_822_507);
        h & 1 == 1
    };
    let finder = |x: i32, y: i32| (x < 7 && y < 7) || (x >= n - 7 && y < 7) || (x < 7 && y >= n - 7);
    let mut cells = String::new();
    for y in 0..n {
        for x in 0..n {
            let on = if finder(x, y) {
                let fx = if x < 7 { x } else { x - (n - 7) };
                let fy = if y < 7 { y } else { y - (n - 7) };
                fx == 0 || fx == 6 || fy == 0 || fy == 6 || ((2..=4).contains(&fx) && (2..=4).contains(&fy))
            } else if (x == 7 || x == n - 8) && (y <= 7 || y >= n - 8) {
                false
            } else if (y == 7 || y == n - 8) && (x <= 7 || x >= n - 8) {
                false
            } else {
                rnd()
            };
            if on {
                cells.push_str(&format!(r##"<rect x="{}" y="{}" width="1" height="1"/>"##, x, y));
            }
        }
    }
    format!(r##"<svg class="qr" viewBox="-1 -1 {} {}" shape-rendering="crispEdges" role="img" aria-label="QR Code do convite">{}</svg>"##, n + 2, n + 2, cells)
}

pub fn invite(result: Option<(&str, &str)>) -> String {
    let out = match result {
        Some((name, link)) => format!(
            r##"{qr}<p style="text-align:center;font-size:11px;color:var(--muted);margin-bottom:10px">Convite para <b>{n}</b> · válido por 48h</p>
<label class="fab-label" for="lk">Link do convite (toque para selecionar e copiar)</label>
<div class="field"><input id="lk" readonly value="{l}"></div>
<a class="btn sm" href="mailto:?subject=Convite%20D.O.M.U.S.&amp;body={enc}" style="width:60%;display:block;margin:0 auto">Compartilhar</a>"##,
            qr = qr_svg(link),
            n = esc(name),
            l = esc(link),
            enc = crate::http::url_encode(link)
        ),
        None => String::new(),
    };
    page(
        "Convidar pessoa",
        &format!(
            r##"<header class="app-header left"><a class="hbtn" href="/perfil" aria-label="Voltar">{}</a><h1 style="text-align:left">Convidar pessoa</h1>{}</header>
<div class="content" style="background:#fff"><form method="post" action="/convidar"><label class="fab-label" for="nm">Nome da pessoa</label>
<div class="field"><input id="nm" name="nome" placeholder="Ex.: Caio Shitado" maxlength="60" required></div><button class="btn">Gerar convite</button></form>
<div style="margin-top:8px">{}</div></div>"##,
            ico("back"),
            ico("chevD"),
            out
        ),
        Some("/perfil"),
    )
}

pub fn accept_invite(token: &str, valid: bool) -> String {
    let body = if valid {
        format!(
            r##"<p style="margin-bottom:16px;font-size:14px">Você foi convidado para participar de uma casa no D.O.M.U.S.</p><form method="post" action="/convite/{}"><button class="btn">Aceitar convite</button></form>"##,
            esc(token)
        )
    } else {
        r##"<p style="font-size:14px">Convite inválido ou expirado.</p><p style="margin-top:12px"><a class="link-btn" href="/login">Ir para o login</a></p>"##.to_string()
    };
    auth_shell("Convite", &body)
}

/* ───────────── Cômodos ───────────── */
pub fn rooms(db: &Db) -> String {
    let items: String = db
        .rooms
        .iter()
        .map(|r| {
            let n = db.active_robots().filter(|x| x.room == r.name && x.status == "working").count();
            format!(
                r##"<form method="post" action="/comodos/{id}/status"><button class="room-item"><span><b>{n}</b><small>{c} robô(s) ligado(s)</small></span><span class="dot {s}"></span></button></form>"##,
                id = r.id, n = esc(&r.name), c = n, s = esc(&r.status)
            )
        })
        .collect();
    page(
        "Cômodos",
        &format!(
            r##"{}<div class="content">{}<p class="section-title" style="margin-top:16px">Status</p>
<div class="legend"><div><span class="dot clean"></span>Limpo</div><div><span class="dot running"></span>Em execução</div><div><span class="dot pending"></span>Pendente</div></div>
<p style="font-size:10px;color:var(--muted);margin-top:10px">Toque em um cômodo para alterar o status.</p></div>"##,
            header("Cômodos da Casa", None, false, ""),
            items
        ),
        Some("/comodos"),
    )
}

/* ───────────── Frota ───────────── */
pub fn fleet(db: &Db, q: &str, tipo: &str) -> String {
    let ql = q.to_lowercase();
    let list: String = db
        .active_robots()
        .filter(|r| ql.is_empty() || r.name.to_lowercase().contains(&ql))
        .filter(|r| tipo.is_empty() || tipo == "Todos" || r.kind == tipo)
        .map(|r| {
            format!(
                r##"<a class="robot-row" href="/robo/{}"><span class="robot-ico s-{}"></span><span class="robot-info"><b>{}</b><small>{} · {}</small></span><span class="battery">{}%</span>{}</a>"##,
                r.id, esc(&r.status), esc(&r.name), esc(&r.kind), esc(&r.room), r.battery, ico_c("chevR", "chev")
            )
        })
        .collect();
    let list = if list.is_empty() { r##"<p class="empty">Nenhum robô encontrado</p>"##.to_string() } else { list };
    let opts: String = std::iter::once("Todos")
        .chain(TYPES.iter().copied())
        .map(|t| format!(r##"<option{}>{}</option>"##, if t == tipo { " selected" } else { "" }, t))
        .collect();
    page(
        "Frota",
        &format!(
            r##"{}<div class="content"><form class="search-row" method="get" action="/frota">
<div class="field"><input name="q" placeholder="Buscar robô..." value="{}"></div>
<div class="field" style="width:96px"><select name="tipo">{}</select><span class="ico">{}</span></div>
<button class="btn sm" style="width:40px;height:40px;padding:0;display:grid;place-items:center" aria-label="Buscar">{}</button></form>
<div class="panel">{}</div><a class="btn" href="/frota/novo" style="margin-top:16px">+ Cadastrar novo robô</a></div>"##,
            header("Frota de Robôs", None, false, ""),
            esc(q),
            opts,
            ico("chevD"),
            ico("search"),
            list
        ),
        Some("/frota"),
    )
}

pub fn new_robot() -> String {
    let types: String = TYPES.iter().map(|t| format!("<option>{}</option>", t)).collect();
    let rooms: String = HOUSE_ROOMS.iter().map(|t| format!("<option>{}</option>", t)).collect();
    page(
        "Novo robô",
        &format!(
            r##"{}<form class="content" method="post" action="/frota/novo">
<div class="field"><input name="nome" placeholder="Nome do robô..." maxlength="40" required></div>
<div class="field"><input name="modelo" placeholder="Modelo do robô..." maxlength="40"></div>
<div class="field"><select name="tipo" required><option value="">Tipo do robô...</option>{}</select><span class="ico">{}</span></div>
<div class="field"><select name="comodo">{}</select><span class="ico">{}</span></div>
<span class="fab-label">Manutenção:</span>
<div class="radios"><label><input type="radio" name="manut" value="3">3 meses</label><label><input type="radio" name="manut" value="6" checked>6 meses</label><label><input type="radio" name="manut" value="12">1 ano</label></div>
<button class="btn" style="width:50%;display:block;margin:0 auto">Salvar</button></form>"##,
            header("Robô", Some("/frota"), false, ""),
            types,
            ico("chevD"),
            rooms,
            ico("chevD")
        ),
        Some("/frota"),
    )
}

fn cmd_form(id: u32, action: &str, task: &str, label: &str, class: &str) -> String {
    format!(
        r##"<form method="post" action="/robo/{}/comando" style="display:contents"><input type="hidden" name="acao" value="{}"><input type="hidden" name="tarefa" value="{}"><button class="{}">{}</button></form>"##,
        id, action, esc(task), class, esc(label)
    )
}

pub fn robot_detail(r: &Robot) -> String {
    let status_txt = match r.status.as_str() {
        "working" => format!("Fazendo:<br>{} ({}%)", esc(&r.task), r.progress),
        "paused" => "Em pausa".to_string(),
        _ => "Na base".to_string(),
    };
    let quick: String = QUICK_TASKS.iter().map(|(l, t)| cmd_form(r.id, "task", t, l, "q")).collect();
    let toggle = if r.status == "paused" { cmd_form(r.id, "resume", "", "Retomar", "btn sm light") } else { cmd_form(r.id, "pause", "", "Pausar", "btn sm light") };
    let right = format!(r##"<a class="hbtn" href="#renomear" aria-label="Renomear">{}</a>"##, ico("edit"));
    page(
        &r.name,
        &format!(
            r##"{header}<div class="content">
<div class="robot-hero"><div class="robot-photo">{svg}</div><div class="meta"><span class="battery" style="justify-content:flex-end">{bat}% {bi}</span><b>{kind}</b><div style="color:var(--muted)">{st}</div></div></div>
<div class="tri"><a class="btn sm" href="#tarefas" style="text-decoration:none;flex:1">Nova tarefa</a>{toggle}{dock}</div>
<div class="panel" style="margin-bottom:12px"><p class="section-title">Informações</p><div class="info-grid">
<span>Modelo</span><span>{model}</span><span>Tipo</span><span>{kind}</span><span>Localização</span><span>{room}</span><span>Tempo de uso</span><span>{hours} horas</span><span>Última manutenção</span><span>{lm}</span></div></div>
<div class="panel" id="tarefas" style="margin-bottom:12px"><p class="section-title">Tarefas rápidas</p><div class="quick">{quick}</div></div>
<details class="edit" id="renomear"><summary class="btn sm light">Renomear robô</summary><form method="post" action="/robo/{id}/renomear" class="inline"><div class="field"><input name="nome" value="{name}" maxlength="40" required></div><button class="btn sm">Salvar nome</button></form></details>
</div>"##,
            header = header(&r.name, Some("/frota"), false, &right),
            svg = ROBOT_SVG,
            bat = r.battery,
            bi = ico("battery"),
            kind = esc(&r.kind),
            st = status_txt,
            toggle = toggle,
            dock = cmd_form(r.id, "dock", "", "Voltar Base", "btn sm light"),
            model = esc(&r.model),
            room = esc(&r.room),
            hours = r.hours,
            lm = br_date(&r.last_maint),
            quick = quick,
            id = r.id,
            name = esc(&r.name)
        ),
        Some("/frota"),
    )
}

/* ───────────── Missões ───────────── */
fn to_min(t: &str) -> i32 {
    let mut p = t.split(':');
    let h: i32 = p.next().and_then(|x| x.parse().ok()).unwrap_or(0);
    let m: i32 = p.next().and_then(|x| x.parse().ok()).unwrap_or(0);
    h * 60 + m
}
fn cat_cls(c: &str) -> String { format!("cat-{}", c.split_whitespace().next().unwrap_or("Limpeza")) }

pub fn missions(db: &Db) -> String {
    let (h0, h1) = (6, 22);
    let span = ((h1 - h0) * 60) as f32;
    let hours: String = (0..=((h1 - h0) / 2)).map(|i| format!("<span>{:02}h</span>", h0 + i * 2)).collect();
    let rows: String = db
        .active_robots()
        .map(|r| {
            let bars: String = db
                .missions
                .iter()
                .filter(|m| m.robot_id == r.id)
                .map(|m| {
                    let l = (((to_min(&m.start) - h0 * 60) as f32) / span * 100.0).clamp(0.0, 100.0);
                    let w = (((to_min(&m.end) - to_min(&m.start)) as f32) / span * 100.0).min(100.0 - l).max(1.0);
                    format!(
                        r##"<span class="g-bar {}" style="left:{:.1}%;width:{:.1}%" title="{} {}–{}">{}</span>"##,
                        cat_cls(&m.category), l, w, esc(&m.title), esc(&m.start), esc(&m.end), esc(&m.title)
                    )
                })
                .collect();
            format!(r##"<div class="g-row"><div class="g-name"><span>{}</span></div><div class="g-track">{}</div></div>"##, esc(&r.name), bars)
        })
        .collect();
    let legend: String = CATS.iter().map(|c| format!(r##"<div><i class="{}"></i>{}</div>"##, cat_cls(c), c)).collect();
    let list: String = db
        .missions
        .iter()
        .map(|m| {
            let who = db.robots.iter().find(|r| r.id == m.robot_id).map(|r| r.name.as_str()).unwrap_or("?");
            format!(
                r##"<form method="post" action="/missoes/{}/remover" class="m-item"><span><b>{}</b><small>{} · {} · {}–{}</small></span><button class="btn sm light" style="width:auto" aria-label="Remover missão">Remover</button></form>"##,
                m.id, esc(&m.title), esc(who), br_date(&m.date), esc(&m.start), esc(&m.end)
            )
        })
        .collect();
    page(
        "Missões",
        &format!(
            r##"{}<div class="content"><p class="section-title">Cronograma de atuação</p>
<div class="gantt"><div class="g-hours" style="grid-template-columns:repeat({},1fr)">{}</div>{}</div>
<div class="g-legend">{}</div>
<a class="btn" href="/missoes/nova" style="width:70%;display:block;margin:0 auto">+ Nova Missão</a>
<p class="section-title" style="margin-top:18px">Missões agendadas</p><div class="panel">{}</div></div>"##,
            header("Missões", None, false, ""),
            (h1 - h0) / 2 + 1,
            hours,
            rows,
            legend,
            if list.is_empty() { r##"<p class="empty">Nenhuma missão</p>"##.to_string() } else { list }
        ),
        Some("/missoes"),
    )
}

pub fn new_mission(db: &Db) -> String {
    let robots: String = db.active_robots().map(|r| format!(r##"<option value="{}">{}</option>"##, r.id, esc(&r.name))).collect();
    let cats: String = CATS.iter().map(|c| format!("<option>{}</option>", c)).collect();
    page(
        "Nova missão",
        &format!(
            r##"{}<form class="content" method="post" action="/missoes/nova">
<div class="field"><input name="titulo" placeholder="Título..." maxlength="60" required></div>
<div class="field"><input name="descricao" placeholder="Descrição..." maxlength="200"></div>
<div class="two"><div class="field"><select name="robo">{}</select><span class="ico">{}</span></div><div class="field"><select name="categoria">{}</select><span class="ico">{}</span></div></div>
<label class="toggle-row"><span>Todo dia</span><input class="sw" type="checkbox" name="todo_dia"></label>
<div class="field"><input name="data" type="date" value="{}" required></div>
<div class="two"><div class="field"><input name="inicio" type="time" value="09:00"></div><div class="field"><input name="fim" type="time" value="10:00"></div></div>
<button class="btn" style="width:50%;display:block;margin:6px auto 0">Salvar</button></form>"##,
            header("Missão", Some("/missoes"), false, ""),
            robots,
            ico("chevD"),
            cats,
            ico("chevD"),
            date_iso(0)
        ),
        Some("/missoes"),
    )
}

pub fn not_found() -> String {
    page("Não encontrado", &format!(r##"{}<div class="content"><p class="empty">Página não encontrada.</p><a class="btn" href="/home">Voltar ao início</a></div>"##, header("Ops", None, false, "")), None)
}

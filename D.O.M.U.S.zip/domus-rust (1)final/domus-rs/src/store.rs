//! Modelos, dados iniciais e persistência (arquivo de texto com campos separados por TAB).

use crate::crypto;
use std::fs;
use std::path::Path;
use std::time::{SystemTime, UNIX_EPOCH};

const PBKDF2_ITERS: u32 = 60_000;

/* ───────────── Tempo ───────────── */
pub fn now_secs() -> u64 {
    SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_secs()).unwrap_or(0)
}

fn tz_offset_secs() -> i64 {
    let h: i64 = std::env::var("DOMUS_TZ_OFFSET_HOURS").ok().and_then(|v| v.parse().ok()).unwrap_or(-3);
    h * 3600
}

fn civil_from_days(z: i64) -> (i64, u32, u32) {
    let z = z + 719_468;
    let era = if z >= 0 { z } else { z - 146_096 } / 146_097;
    let doe = z - era * 146_097;
    let yoe = (doe - doe / 1460 + doe / 36_524 - doe / 146_096) / 365;
    let y = yoe + era * 400;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153;
    let d = (doy - (153 * mp + 2) / 5 + 1) as u32;
    let m = if mp < 10 { mp + 3 } else { mp - 9 } as u32;
    (if m <= 2 { y + 1 } else { y }, m, d)
}

/// Data local no formato AAAA-MM-DD, `days` dias a partir de hoje.
pub fn date_iso(days: i64) -> String {
    let local = now_secs() as i64 + tz_offset_secs() + days * 86_400;
    let (y, m, d) = civil_from_days(local.div_euclid(86_400));
    format!("{:04}-{:02}-{:02}", y, m, d)
}

pub fn local_hour() -> u32 {
    let local = now_secs() as i64 + tz_offset_secs();
    (local.rem_euclid(86_400) / 3600) as u32
}

/* ───────────── Senhas ───────────── */
pub fn hash_pw(pw: &str) -> String {
    let salt = crypto::random_bytes(16);
    format!("{}:{}:{}", PBKDF2_ITERS, crypto::hex(&salt), crypto::hex(&crypto::pbkdf2(pw.as_bytes(), &salt, PBKDF2_ITERS)))
}

pub fn verify_pw(pw: &str, stored: &str) -> bool {
    let p: Vec<&str> = stored.split(':').collect();
    if p.len() != 3 {
        return false;
    }
    let (Ok(iters), Some(salt), Some(want)) = (p[0].parse::<u32>(), crypto::unhex(p[1]), crypto::unhex(p[2])) else {
        return false;
    };
    crypto::ct_eq(&crypto::pbkdf2(pw.as_bytes(), &salt, iters), &want)
}

/// Gasta o mesmo tempo de uma verificação real (evita revelar se o e-mail existe).
pub fn dummy_verify() {
    let _ = crypto::pbkdf2(b"x", b"0123456789abcdef", PBKDF2_ITERS);
}

/* ───────────── Modelos ───────────── */
#[derive(Clone)]
pub struct User { pub id: u32, pub name: String, pub email: String, pub pw: String, pub biometric: bool, pub house: String }
#[derive(Clone)]
pub struct Member { pub id: u32, pub name: String }
#[derive(Clone)]
pub struct Room { pub id: u32, pub name: String, pub status: String }
#[derive(Clone)]
pub struct Robot {
    pub id: u32, pub name: String, pub kind: String, pub model: String, pub room: String, pub status: String,
    pub task: String, pub progress: u32, pub battery: u32, pub hours: u32, pub last_maint: String,
    pub maint_every: u32, pub removed: bool,
}
#[derive(Clone)]
pub struct Alert { pub id: u32, pub level: String, pub title: String, pub text: String, pub time: String }
#[derive(Clone)]
pub struct Maint { pub id: u32, pub robot_id: u32, pub level: String, pub note: String, pub status: String, pub scheduled_for: String }
#[derive(Clone)]
pub struct Mission {
    pub id: u32, pub robot_id: u32, pub title: String, pub desc: String, pub category: String,
    pub date: String, pub start: String, pub end: String, pub all_day: bool,
}
#[derive(Clone)]
pub struct Invite { pub token: String, pub name: String, pub expires: u64 }

#[derive(Clone, Default)]
pub struct Db {
    pub seq: u32,
    pub users: Vec<User>,
    pub family: Vec<Member>,
    pub rooms: Vec<Room>,
    pub robots: Vec<Robot>,
    pub alerts: Vec<Alert>,
    pub maints: Vec<Maint>,
    pub missions: Vec<Mission>,
    pub invites: Vec<Invite>,
}

impl Db {
    pub fn next_id(&mut self) -> u32 {
        self.seq += 1;
        self.seq
    }
    pub fn user(&self, id: u32) -> Option<&User> { self.users.iter().find(|u| u.id == id) }
    pub fn active_robots(&self) -> impl Iterator<Item = &Robot> { self.robots.iter().filter(|r| !r.removed) }
    pub fn robot(&self, id: u32) -> Option<&Robot> { self.active_robots().find(|r| r.id == id) }
    pub fn robot_mut(&mut self, id: u32) -> Option<&mut Robot> { self.robots.iter_mut().find(|r| r.id == id && !r.removed) }

    pub fn seed() -> Db {
        let s = |x: &str| x.to_string();
        let robot = |id, name: &str, kind: &str, model: &str, room: &str, status: &str, task: &str, progress, battery, hours, lm: &str, every| Robot {
            id, name: s(name), kind: s(kind), model: s(model), room: s(room), status: s(status), task: s(task),
            progress, battery, hours, last_maint: s(lm), maint_every: every, removed: false,
        };
        let alert = |id, level: &str, title: &str, text: &str, time: &str| Alert { id, level: s(level), title: s(title), text: s(text), time: s(time) };
        let maint = |id, robot_id, level: &str, note: &str| Maint { id, robot_id, level: s(level), note: s(note), status: s("open"), scheduled_for: String::new() };
        let mission = |id, robot_id, title: &str, cat: &str, start: &str, end: &str| Mission {
            id, robot_id, title: s(title), desc: String::new(), category: s(cat), date: date_iso(0), start: s(start), end: s(end), all_day: false,
        };
        Db {
            seq: 100,
            users: vec![User { id: 1, name: s("Robertão"), email: s("robertao@email.com"), pw: hash_pw("domus123"), biometric: true, house: s("Minha casa") }],
            family: vec![Member { id: 1, name: s("Camila") }, Member { id: 2, name: s("Carlito") }, Member { id: 3, name: s("Amandinha") }],
            rooms: vec![
                Room { id: 1, name: s("Sala"), status: s("clean") },
                Room { id: 2, name: s("Cozinha"), status: s("clean") },
                Room { id: 3, name: s("Quarto 1"), status: s("running") },
                Room { id: 4, name: s("Quarto 2"), status: s("pending") },
                Room { id: 5, name: s("Banheiro"), status: s("pending") },
            ],
            robots: vec![
                robot(1, "Aspirador Max", "Aspirador", "CleanBot X1", "Sala", "working", "Aspirando a sala", 70, 78, 128, "2026-10-18", 3),
                robot(2, "Passa-pano Bia", "Passa-pano", "MopBot M2", "Cozinha", "working", "Passando pano", 40, 92, 64, "2026-09-02", 6),
                robot(3, "Chef Lia", "Cozinha", "ChefBot C3", "Cozinha", "working", "Preparando jantar", 55, 66, 210, "2026-08-14", 6),
                robot(4, "Lavanderia Tom", "Lavanderia", "WashBot L1", "Quarto 2", "paused", "Em pausa", 70, 81, 97, "2026-07-21", 12),
                robot(5, "Drone Pip", "Drone", "SkyEye D5", "Sala", "docked", "Na base", 0, 100, 33, "2026-10-01", 6),
                robot(6, "Lava-Louças Leo", "Lava louças", "DishBot D2", "Cozinha", "paused", "Em pausa", 20, 59, 150, "2026-06-30", 6),
            ],
            alerts: vec![
                alert(1, "crit", "Movimentação suspeita", "Sensor detectou movimento no quintal", "Hoje 22:41"),
                alert(2, "ok", "Acesso autorizado", "Portão aberto por Camila", "Hoje 21:10"),
                alert(3, "warn", "Tentativa de acesso", "Login não reconhecido", "Hoje 19:30"),
                alert(4, "info", "Sistema seguro", "Todos os sensores estão funcionando", "Hoje 18:00"),
                alert(5, "crit", "Alerta de rede", "Conexão instável com o roteador", "Hoje 16:20"),
            ],
            maints: vec![
                maint(1, 1, "warn", "Filtro – 4 dias"),
                maint(2, 3, "crit", "Motor com superaquecimento"),
                maint(3, 5, "info", "Bateria – 12 dias"),
                maint(4, 2, "ok", "Realizado"),
            ],
            missions: vec![
                mission(1, 1, "Limpar sala", "Limpeza", "08:00", "10:00"),
                mission(2, 2, "Passar pano", "Limpeza", "09:00", "11:00"),
                mission(3, 3, "Almoço", "Cozinha", "10:30", "12:30"),
                mission(4, 4, "Lavar roupas", "Lavanderia", "13:00", "15:30"),
                mission(5, 5, "Ronda externa", "Fora da casa", "18:00", "20:00"),
            ],
            invites: vec![],
        }
    }

    /* ───────────── Persistência ───────────── */
    pub fn save(&self, path: &Path) {
        let mut out = String::new();
        out.push_str(&row("seq", vec![self.seq.to_string()]));
        for u in &self.users {
            out.push_str(&row("user", vec![u.id.to_string(), u.name.clone(), u.email.clone(), u.pw.clone(), (u.biometric as u8).to_string(), u.house.clone()]));
        }
        for m in &self.family { out.push_str(&row("family", vec![m.id.to_string(), m.name.clone()])); }
        for r in &self.rooms { out.push_str(&row("room", vec![r.id.to_string(), r.name.clone(), r.status.clone()])); }
        for r in &self.robots {
            out.push_str(&row("robot", vec![
                r.id.to_string(), r.name.clone(), r.kind.clone(), r.model.clone(), r.room.clone(), r.status.clone(), r.task.clone(),
                r.progress.to_string(), r.battery.to_string(), r.hours.to_string(), r.last_maint.clone(), r.maint_every.to_string(), (r.removed as u8).to_string(),
            ]));
        }
        for a in &self.alerts { out.push_str(&row("alert", vec![a.id.to_string(), a.level.clone(), a.title.clone(), a.text.clone(), a.time.clone()])); }
        for m in &self.maints {
            out.push_str(&row("maint", vec![m.id.to_string(), m.robot_id.to_string(), m.level.clone(), m.note.clone(), m.status.clone(), m.scheduled_for.clone()]));
        }
        for m in &self.missions {
            out.push_str(&row("mission", vec![
                m.id.to_string(), m.robot_id.to_string(), m.title.clone(), m.desc.clone(), m.category.clone(), m.date.clone(), m.start.clone(), m.end.clone(), (m.all_day as u8).to_string(),
            ]));
        }
        for i in &self.invites { out.push_str(&row("invite", vec![i.token.clone(), i.name.clone(), i.expires.to_string()])); }
        let tmp = path.with_extension("tmp");
        if fs::write(&tmp, out).is_ok() {
            let _ = fs::rename(&tmp, path);
        }
    }

    pub fn load(path: &Path) -> Option<Db> {
        let txt = fs::read_to_string(path).ok()?;
        let mut db = Db::default();
        for line in txt.lines() {
            let p: Vec<String> = line.split('\t').map(unesc).collect();
            let n = |i: usize| -> u32 { p.get(i).and_then(|x| x.parse().ok()).unwrap_or(0) };
            let s = |i: usize| -> String { p.get(i).cloned().unwrap_or_default() };
            match p[0].as_str() {
                "seq" => db.seq = n(1),
                "user" => db.users.push(User { id: n(1), name: s(2), email: s(3), pw: s(4), biometric: n(5) == 1, house: s(6) }),
                "family" => db.family.push(Member { id: n(1), name: s(2) }),
                "room" => db.rooms.push(Room { id: n(1), name: s(2), status: s(3) }),
                "robot" => db.robots.push(Robot {
                    id: n(1), name: s(2), kind: s(3), model: s(4), room: s(5), status: s(6), task: s(7), progress: n(8), battery: n(9),
                    hours: n(10), last_maint: s(11), maint_every: n(12), removed: n(13) == 1,
                }),
                "alert" => db.alerts.push(Alert { id: n(1), level: s(2), title: s(3), text: s(4), time: s(5) }),
                "maint" => db.maints.push(Maint { id: n(1), robot_id: n(2), level: s(3), note: s(4), status: s(5), scheduled_for: s(6) }),
                "mission" => db.missions.push(Mission {
                    id: n(1), robot_id: n(2), title: s(3), desc: s(4), category: s(5), date: s(6), start: s(7), end: s(8), all_day: n(9) == 1,
                }),
                "invite" => db.invites.push(Invite { token: s(1), name: s(2), expires: s(3).parse().unwrap_or(0) }),
                _ => {}
            }
        }
        if db.users.is_empty() { None } else { Some(db) }
    }
}

fn esc(s: &str) -> String {
    s.replace('\\', "\\\\").replace('\t', "\\t").replace('\n', "\\n").replace('\r', "\\r")
}

fn unesc(s: &str) -> String {
    let mut o = String::with_capacity(s.len());
    let mut it = s.chars();
    while let Some(c) = it.next() {
        if c == '\\' {
            match it.next() {
                Some('t') => o.push('\t'),
                Some('n') => o.push('\n'),
                Some('r') => o.push('\r'),
                Some(x) => o.push(x),
                None => {}
            }
        } else {
            o.push(c);
        }
    }
    o
}

fn row(kind: &str, f: Vec<String>) -> String {
    let mut s = kind.to_string();
    for x in f {
        s.push('\t');
        s.push_str(&esc(&x));
    }
    s.push('\n');
    s
}

//! D.O.M.U.S. – Smart Fleet Manager
//! Aplicação 100% Rust (apenas a biblioteca padrão): servidor HTTP, regras de negócio e telas.

mod crypto;
mod http;
mod store;
mod views;

use http::{Req, Resp};
use std::fs;
use std::net::{TcpListener, TcpStream};
use std::path::PathBuf;
use std::sync::{Arc, Mutex, MutexGuard};
use std::thread;
use std::time::Duration;
use store::*;

const CSS_BASE: &str = include_str!("../static/styles.css");
const CSS_EXTRA: &str = include_str!("../static/extra.css");
const SESSION_SECS: u64 = 7 * 24 * 3600;

struct App {
    db: Mutex<Db>,
    db_path: PathBuf,
    secret: Vec<u8>,
}

impl App {
    fn lock(&self) -> MutexGuard<'_, Db> {
        self.db.lock().unwrap_or_else(|e| e.into_inner())
    }
    fn save(&self, db: &Db) {
        db.save(&self.db_path);
    }

    fn make_session(&self, uid: u32) -> String {
        let payload = format!("{}.{}", uid, now_secs() + SESSION_SECS);
        let sig = crypto::hex(&crypto::hmac_sha256(&self.secret, payload.as_bytes()));
        format!("domus={}.{}; Path=/; HttpOnly; SameSite=Lax; Max-Age={}", payload, sig, SESSION_SECS)
    }

    fn session(&self, req: &Req) -> Option<u32> {
        let c = req.cookie("domus")?;
        let mut p = c.split('.');
        let (uid, exp, sig) = (p.next()?, p.next()?, p.next()?);
        let payload = format!("{}.{}", uid, exp);
        let want = crypto::hex(&crypto::hmac_sha256(&self.secret, payload.as_bytes()));
        if !crypto::ct_eq(want.as_bytes(), sig.as_bytes()) || exp.parse::<u64>().ok()? < now_secs() {
            return None;
        }
        let uid: u32 = uid.parse().ok()?;
        self.lock().user(uid).map(|_| uid)
    }

    fn login_ok(&self, uid: u32) -> Resp {
        Resp::redirect("/home").cookie(self.make_session(uid))
    }
}

/* ───────────── Helpers ───────────── */
fn clean(s: &str, max: usize) -> String {
    s.trim().chars().filter(|c| !c.is_control()).take(max).collect()
}

fn email_ok(e: &str) -> bool {
    let Some((l, d)) = e.split_once('@') else { return false };
    !l.is_empty() && !e.contains(char::is_whitespace) && d.contains('.') && !d.starts_with('.') && !d.ends_with('.') && !d.contains('@')
}

fn time_ok(t: &str) -> bool {
    let b = t.as_bytes();
    b.len() == 5
        && b[2] == b':'
        && b[..2].iter().chain(b[3..].iter()).all(|c| c.is_ascii_digit())
        && t[..2].parse::<u32>().map_or(false, |h| h < 24)
        && t[3..].parse::<u32>().map_or(false, |m| m < 60)
}

fn date_ok(d: &str) -> bool {
    let p: Vec<&str> = d.split('-').collect();
    p.len() == 3
        && p[0].len() == 4
        && p[1].len() == 2
        && p[2].len() == 2
        && p.iter().all(|x| x.chars().all(|c| c.is_ascii_digit()))
        && p[1].parse::<u32>().map_or(false, |m| (1..=12).contains(&m))
        && p[2].parse::<u32>().map_or(false, |d| (1..=31).contains(&d))
}

/// Redireciona com uma mensagem (cookie "flash", lido e apagado na próxima tela).
fn back(to: &str, msg: &str, err: bool) -> Resp {
    let v = http::url_encode(&format!("{}{}", if err { 'e' } else { 'o' }, msg));
    Resp::redirect(to).cookie(format!("flash={}; Path=/; Max-Age=30; HttpOnly; SameSite=Lax", v))
}

fn parse_id(s: &str) -> Option<u32> {
    s.parse().ok()
}

/* ───────────── Rotas ───────────── */
fn route(app: &App, req: &Req) -> Resp {
    let segs: Vec<&str> = req.path.trim_matches('/').split('/').collect();
    let m = req.method.as_str();

    // Públicas
    match (m, segs.as_slice()) {
        ("GET", ["static", "styles.css"]) => return Resp::css(CSS_BASE),
        ("GET", ["static", "extra.css"]) => return Resp::css(CSS_EXTRA),
        ("GET", [""]) => return Resp::redirect(if app.session(req).is_some() { "/home" } else { "/login" }),
        ("GET", ["login"]) | ("GET", ["entrar"]) | ("GET", ["cadastro"]) if app.session(req).is_some() => return Resp::redirect("/home"),
        ("GET", ["login"]) => return Resp::html(views::login()),
        ("GET", ["entrar"]) => return Resp::html(views::email_login()),
        ("GET", ["cadastro"]) => return Resp::html(views::register()),
        ("GET", ["redefinir"]) => return Resp::html(views::reset()),
        ("POST", ["entrar"]) => {
            let email = clean(&req.param("email"), 120).to_lowercase();
            let pw = req.param("senha");
            let user = app.lock().users.iter().find(|u| u.email == email).cloned();
            return match user {
                Some(u) if verify_pw(&pw, &u.pw) => app.login_ok(u.id),
                Some(_) => back("/entrar", "E-mail ou senha incorretos", true),
                None => {
                    dummy_verify();
                    back("/entrar", "E-mail ou senha incorretos", true)
                }
            };
        }
        ("POST", ["biometria"]) => {
            // Biometria simulada: em um app nativo o aparelho valida a digital e confirma ao servidor.
            let uid = app.lock().users.iter().find(|u| u.biometric).map(|u| u.id);
            return match uid {
                Some(id) => app.login_ok(id),
                None => back("/login", "Nenhuma biometria cadastrada", true),
            };
        }
        ("POST", ["cadastro"]) => {
            let email = clean(&req.param("email"), 120).to_lowercase();
            let (pw, pw2) = (req.param("senha"), req.param("confirmar"));
            if !email_ok(&email) {
                return back("/cadastro", "E-mail inválido", true);
            }
            if pw.chars().count() < 6 {
                return back("/cadastro", "A senha deve ter ao menos 6 caracteres", true);
            }
            if pw != pw2 {
                return back("/cadastro", "As senhas não conferem", true);
            }
            if app.lock().users.iter().any(|u| u.email == email) {
                return back("/cadastro", "E-mail já cadastrado", true);
            }
            let hashed = hash_pw(&pw); // fora do lock: é uma operação lenta de propósito
            let mut db = app.lock();
            let id = db.next_id();
            let name = email.split('@').next().unwrap_or("Usuário").to_string();
            db.users.push(User { id, name, email, pw: hashed, biometric: false, house: "Minha casa".into() });
            app.save(&db);
            drop(db);
            return app.login_ok(id);
        }
        ("POST", ["redefinir"]) => {
            let (e1, e2) = (clean(&req.param("email"), 120).to_lowercase(), clean(&req.param("confirmar"), 120).to_lowercase());
            if !email_ok(&e1) {
                return back("/redefinir", "E-mail inválido", true);
            }
            if e1 != e2 {
                return back("/redefinir", "Os e-mails não conferem", true);
            }
            // Não revela se o e-mail existe. Em produção: enviar e-mail com link de redefinição.
            return back("/entrar", "Se o e-mail estiver cadastrado, enviaremos as instruções.", false);
        }
        ("GET", ["convite", token]) => {
            let valid = app.lock().invites.iter().any(|i| i.token == *token && i.expires > now_secs());
            return Resp::html(views::accept_invite(token, valid));
        }
        ("POST", ["convite", token]) => {
            let mut db = app.lock();
            let Some(pos) = db.invites.iter().position(|i| i.token == *token && i.expires > now_secs()) else {
                return back("/login", "Convite inválido ou expirado", true);
            };
            let inv = db.invites.remove(pos);
            let id = db.next_id();
            db.family.push(Member { id, name: inv.name });
            app.save(&db);
            drop(db);
            let to = if app.session(req).is_some() { "/perfil" } else { "/login" };
            return back(to, "Convite aceito!", false);
        }
        _ => {}
    }

    // Protegidas
    let Some(uid) = app.session(req) else { return Resp::redirect("/login") };

    match (m, segs.as_slice()) {
        ("POST", ["sair"]) => Resp::redirect("/login").cookie("domus=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0".into()),

        ("GET", ["home"]) => {
            let db = app.lock();
            match db.user(uid) {
                Some(u) => Resp::html(views::home(&db, u)),
                None => Resp::redirect("/login"),
            }
        }
        ("POST", ["parar-todos"]) => {
            let mut db = app.lock();
            let mut n = 0;
            for r in db.robots.iter_mut().filter(|r| !r.removed && r.status == "working") {
                r.status = "paused".into();
                r.task = "Em pausa".into();
                n += 1;
            }
            app.save(&db);
            back("/home", &format!("{} robô(s) pausado(s)", n), false)
        }

        ("GET", ["alertas"]) => Resp::html(views::alerts(&app.lock(), req.param("tab") == "man")),
        ("POST", ["manutencao", acao @ ("agendar" | "retirar")]) => {
            let Some(id) = parse_id(&req.param("id")) else {
                return back("/alertas?tab=man", "Selecione um item da lista", true);
            };
            let mut db = app.lock();
            let Some(mi) = db.maints.iter().position(|x| x.id == id && x.status == "open") else {
                return back("/alertas?tab=man", "Item de manutenção não encontrado", true);
            };
            let robot_id = db.maints[mi].robot_id;
            if *acao == "agendar" {
                let date = date_iso(3);
                db.maints[mi].status = "scheduled".into();
                db.maints[mi].scheduled_for = date.clone();
                if let Some(r) = db.robots.iter_mut().find(|r| r.id == robot_id) {
                    r.last_maint = date.clone();
                }
                app.save(&db);
                back("/alertas?tab=man", &format!("Reparo agendado para {}", date.split('-').rev().collect::<Vec<_>>().join("/")), false)
            } else {
                db.maints[mi].status = "removed".into();
                if let Some(r) = db.robots.iter_mut().find(|r| r.id == robot_id) {
                    r.removed = true;
                    r.status = "docked".into();
                }
                app.save(&db);
                back("/alertas?tab=man", "Robô retirado da frota", false)
            }
        }

        ("GET", ["perfil"]) => {
            let db = app.lock();
            match db.user(uid) {
                Some(u) => Resp::html(views::profile(&db, u)),
                None => Resp::redirect("/login"),
            }
        }
        ("POST", ["perfil", "email"]) => {
            let email = clean(&req.param("email"), 120).to_lowercase();
            if !email_ok(&email) {
                return back("/perfil", "E-mail inválido", true);
            }
            let mut db = app.lock();
            if db.users.iter().any(|u| u.email == email && u.id != uid) {
                return back("/perfil", "E-mail já em uso", true);
            }
            if let Some(u) = db.users.iter_mut().find(|u| u.id == uid) {
                u.email = email;
            }
            app.save(&db);
            back("/perfil", "E-mail atualizado", false)
        }
        ("POST", ["perfil", "biometria"]) => {
            let mut db = app.lock();
            if let Some(u) = db.users.iter_mut().find(|u| u.id == uid) {
                u.biometric = true;
            }
            app.save(&db);
            back("/perfil", "Biometria registrada neste dispositivo", false)
        }

        ("GET", ["convidar"]) => Resp::html(views::invite(None)),
        ("POST", ["convidar"]) => {
            let name = clean(&req.param("nome"), 60);
            if name.is_empty() {
                return back("/convidar", "Informe o nome da pessoa", true);
            }
            let token = crypto::hex(&crypto::random_bytes(16));
            let mut db = app.lock();
            let now = now_secs();
            db.invites.retain(|i| i.expires > now);
            db.invites.push(Invite { token: token.clone(), name: name.clone(), expires: now + 48 * 3600 });
            app.save(&db);
            let link = format!("{}://{}/convite/{}", req.proto, req.host, token);
            Resp::html(views::invite(Some((&name, &link))))
        }

        ("GET", ["comodos"]) => Resp::html(views::rooms(&app.lock())),
        ("POST", ["comodos", id, "status"]) => {
            let mut db = app.lock();
            if let Some(r) = parse_id(id).and_then(|i| db.rooms.iter_mut().find(|r| r.id == i)) {
                r.status = match r.status.as_str() {
                    "clean" => "running",
                    "running" => "pending",
                    _ => "clean",
                }
                .into();
                app.save(&db);
            }
            Resp::redirect("/comodos")
        }

        ("GET", ["frota"]) => Resp::html(views::fleet(&app.lock(), &clean(&req.param("q"), 60), &req.param("tipo"))),
        ("GET", ["frota", "novo"]) => Resp::html(views::new_robot()),
        ("POST", ["frota", "novo"]) => {
            let name = clean(&req.param("nome"), 40);
            let kind = req.param("tipo");
            if name.is_empty() {
                return back("/frota/novo", "Informe o nome do robô", true);
            }
            if !views::TYPES.contains(&kind.as_str()) {
                return back("/frota/novo", "Selecione o tipo do robô", true);
            }
            let room = req.param("comodo");
            let room = if views::HOUSE_ROOMS.contains(&room.as_str()) { room } else { "Sala".into() };
            let every = match req.param("manut").as_str() {
                "3" => 3,
                "12" => 12,
                _ => 6,
            };
            let model = clean(&req.param("modelo"), 40);
            let mut db = app.lock();
            let id = db.next_id();
            db.robots.push(Robot {
                id, name, kind, model: if model.is_empty() { "Genérico".into() } else { model }, room, status: "docked".into(),
                task: "Na base".into(), progress: 0, battery: 100, hours: 0, last_maint: date_iso(0), maint_every: every, removed: false,
            });
            app.save(&db);
            back("/frota", "Robô cadastrado!", false)
        }
        ("GET", ["robo", id]) => {
            let db = app.lock();
            match parse_id(id).and_then(|i| db.robot(i)) {
                Some(r) => Resp::html(views::robot_detail(r)),
                None => back("/frota", "Robô não encontrado", true),
            }
        }
        ("POST", ["robo", id, "comando"]) => {
            let Some(rid) = parse_id(id) else { return back("/frota", "Robô não encontrado", true) };
            let mut db = app.lock();
            let to = format!("/robo/{}", rid);
            let Some(r) = db.robot_mut(rid) else { return back("/frota", "Robô não encontrado", true) };
            match req.param("acao").as_str() {
                "pause" => {
                    r.status = "paused".into();
                    r.task = "Em pausa".into();
                }
                "dock" => {
                    r.status = "docked".into();
                    r.task = "Na base".into();
                    r.progress = 0;
                }
                "resume" => {
                    r.status = "working".into();
                    if r.task == "Em pausa" || r.task == "Na base" {
                        r.task = "Retomando tarefa".into();
                    }
                }
                "task" => {
                    let t = req.param("tarefa");
                    if !views::QUICK_TASKS.iter().any(|(_, x)| *x == t) {
                        return back(&to, "Tarefa inválida", true);
                    }
                    r.status = "working".into();
                    r.task = t;
                    r.progress = 0;
                }
                _ => return back(&to, "Comando inválido", true),
            }
            app.save(&db);
            back(&to, "Comando enviado", false)
        }
        ("POST", ["robo", id, "renomear"]) => {
            let Some(rid) = parse_id(id) else { return back("/frota", "Robô não encontrado", true) };
            let name = clean(&req.param("nome"), 40);
            let to = format!("/robo/{}", rid);
            if name.is_empty() {
                return back(&to, "Nome inválido", true);
            }
            let mut db = app.lock();
            match db.robot_mut(rid) {
                Some(r) => r.name = name,
                None => return back("/frota", "Robô não encontrado", true),
            }
            app.save(&db);
            back(&to, "Nome atualizado", false)
        }

        ("GET", ["missoes"]) => Resp::html(views::missions(&app.lock())),
        ("GET", ["missoes", "nova"]) => Resp::html(views::new_mission(&app.lock())),
        ("POST", ["missoes", "nova"]) => {
            let title = clean(&req.param("titulo"), 60);
            if title.is_empty() {
                return back("/missoes/nova", "Informe o título da missão", true);
            }
            let all_day = req.has("todo_dia");
            let (start, end) = if all_day { ("06:00".to_string(), "22:00".to_string()) } else { (req.param("inicio"), req.param("fim")) };
            if !time_ok(&start) || !time_ok(&end) {
                return back("/missoes/nova", "Horário inválido", true);
            }
            if end <= start {
                return back("/missoes/nova", "O horário final deve ser depois do inicial", true);
            }
            let date = req.param("data");
            if !date_ok(&date) {
                return back("/missoes/nova", "Data inválida", true);
            }
            let cat = req.param("categoria");
            let cat = if views::CATS.contains(&cat.as_str()) { cat } else { "Limpeza".into() };
            let mut db = app.lock();
            let Some(robot_id) = parse_id(&req.param("robo")).filter(|i| db.robot(*i).is_some()) else {
                return back("/missoes/nova", "Selecione um robô", true);
            };
            let id = db.next_id();
            db.missions.push(Mission { id, robot_id, title, desc: clean(&req.param("descricao"), 200), category: cat, date, start, end, all_day });
            app.save(&db);
            back("/missoes", "Missão criada!", false)
        }
        ("POST", ["missoes", id, "remover"]) => {
            let mut db = app.lock();
            if let Some(i) = parse_id(id) {
                db.missions.retain(|m| m.id != i);
                app.save(&db);
            }
            back("/missoes", "Missão removida", false)
        }

        _ => Resp::html_status(404, views::not_found()),
    }
}

fn handle(app: &App, mut stream: TcpStream) {
    let _ = stream.set_read_timeout(Some(Duration::from_secs(10)));
    let _ = stream.set_write_timeout(Some(Duration::from_secs(10)));
    let Some(req) = http::read_request(&mut stream) else {
        http::write_response(&mut stream, &Resp::text(400, "Requisição inválida"));
        return;
    };
    let mut resp = route(app, &req);

    // Aviso (flash): injeta na página e apaga o cookie.
    if resp.status < 300 && resp.ctype.starts_with("text/html") {
        let mut flash_html = String::new();
        if let Some(raw) = req.cookie("flash") {
            let v = http::url_decode(raw);
            let (kind, msg) = v.split_at(v.chars().next().map_or(0, |c| c.len_utf8()));
            flash_html = format!(r##"<div class="toast show{}" role="status">{}</div>"##, if kind == "e" { " err" } else { "" }, views::esc(msg));
            resp.headers.push(("Set-Cookie".into(), "flash=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax".into()));
        }
        let body = String::from_utf8_lossy(&resp.body).replace("<!--FLASH-->", &flash_html);
        resp.body = body.into_bytes();
    }
    http::write_response(&mut stream, &resp);
}

fn load_secret(path: &PathBuf) -> Vec<u8> {
    if let Ok(s) = std::env::var("DOMUS_SECRET") {
        return s.into_bytes();
    }
    if let Ok(s) = fs::read_to_string(path) {
        if let Some(b) = crypto::unhex(s.trim()) {
            return b;
        }
    }
    let b = crypto::random_bytes(32);
    let _ = fs::write(path, crypto::hex(&b));
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        let _ = fs::set_permissions(path, fs::Permissions::from_mode(0o600));
    }
    b
}

fn main() {
    let port = std::env::var("PORT").unwrap_or_else(|_| "3000".into());
    let bind = std::env::var("DOMUS_BIND").unwrap_or_else(|_| "127.0.0.1".into());
    let data = PathBuf::from(std::env::var("DOMUS_DATA").unwrap_or_else(|_| "data".into()));
    fs::create_dir_all(&data).expect("não foi possível criar a pasta de dados");
    let db_path = data.join("db.txt");
    let db = Db::load(&db_path).unwrap_or_else(|| {
        let d = Db::seed();
        d.save(&db_path);
        d
    });
    let app = Arc::new(App { db: Mutex::new(db), db_path, secret: load_secret(&data.join("secret.key")) });

    let listener = TcpListener::bind(format!("{}:{}", bind, port)).expect("não foi possível abrir a porta");
    println!("D.O.M.U.S. rodando em http://{}:{}", bind, port);
    for stream in listener.incoming().flatten() {
        let app = Arc::clone(&app);
        thread::spawn(move || handle(&app, stream));
    }
}

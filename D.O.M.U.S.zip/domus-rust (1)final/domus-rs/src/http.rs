//! Servidor HTTP/1.1 mínimo sobre std::net.

use std::io::{Read, Write};
use std::net::TcpStream;

const MAX_HEADER: usize = 16 * 1024;
const MAX_BODY: usize = 64 * 1024;

pub struct Req {
    pub method: String,
    pub path: String,
    pub query: Vec<(String, String)>,
    pub form: Vec<(String, String)>,
    pub cookies: Vec<(String, String)>,
    pub host: String,
    pub proto: String,
}

impl Req {
    /// Valor de um campo de formulário (ou da query string).
    pub fn param(&self, key: &str) -> String {
        self.form
            .iter()
            .chain(self.query.iter())
            .find(|(k, _)| k == key)
            .map(|(_, v)| v.clone())
            .unwrap_or_default()
    }
    pub fn has(&self, key: &str) -> bool {
        self.form.iter().chain(self.query.iter()).any(|(k, _)| k == key)
    }
    pub fn cookie(&self, key: &str) -> Option<&str> {
        self.cookies.iter().find(|(k, _)| k == key).map(|(_, v)| v.as_str())
    }
}

pub struct Resp {
    pub status: u16,
    pub ctype: &'static str,
    pub headers: Vec<(String, String)>,
    pub body: Vec<u8>,
}

impl Resp {
    pub fn new(status: u16, ctype: &'static str, body: Vec<u8>) -> Resp {
        Resp { status, ctype, headers: vec![], body }
    }
    pub fn html(s: String) -> Resp {
        Resp::new(200, "text/html; charset=utf-8", s.into_bytes())
    }
    pub fn html_status(status: u16, s: String) -> Resp {
        Resp::new(status, "text/html; charset=utf-8", s.into_bytes())
    }
    pub fn css(s: &str) -> Resp {
        let mut r = Resp::new(200, "text/css; charset=utf-8", s.as_bytes().to_vec());
        r.headers.push(("Cache-Control".into(), "public, max-age=300".into()));
        r
    }
    pub fn redirect(to: &str) -> Resp {
        let mut r = Resp::new(303, "text/plain; charset=utf-8", vec![]);
        r.headers.push(("Location".into(), to.into()));
        r
    }
    pub fn text(status: u16, s: &str) -> Resp {
        Resp::new(status, "text/plain; charset=utf-8", s.as_bytes().to_vec())
    }
    pub fn cookie(mut self, c: String) -> Resp {
        self.headers.push(("Set-Cookie".into(), c));
        self
    }
}

pub fn url_decode(s: &str) -> String {
    let b = s.as_bytes();
    let mut out = Vec::with_capacity(b.len());
    let mut i = 0;
    while i < b.len() {
        match b[i] {
            b'+' => out.push(b' '),
            b'%' if i + 2 < b.len() => {
                match s.get(i + 1..i + 3).and_then(|h| u8::from_str_radix(h, 16).ok()) {
                    Some(v) => {
                        out.push(v);
                        i += 2;
                    }
                    None => out.push(b'%'),
                }
            }
            c => out.push(c),
        }
        i += 1;
    }
    String::from_utf8_lossy(&out).into_owned()
}

pub fn url_encode(s: &str) -> String {
    let mut o = String::new();
    for b in s.bytes() {
        if b.is_ascii_alphanumeric() || b"-_.~".contains(&b) {
            o.push(b as char);
        } else {
            o.push_str(&format!("%{:02X}", b));
        }
    }
    o
}

pub fn parse_pairs(s: &str) -> Vec<(String, String)> {
    s.split('&')
        .filter(|p| !p.is_empty())
        .map(|p| {
            let (k, v) = p.split_once('=').unwrap_or((p, ""));
            (url_decode(k), url_decode(v))
        })
        .collect()
}

pub fn read_request(stream: &mut TcpStream) -> Option<Req> {
    let mut buf: Vec<u8> = Vec::new();
    let mut tmp = [0u8; 4096];
    let head_end = loop {
        if let Some(p) = buf.windows(4).position(|w| w == b"\r\n\r\n") {
            break p;
        }
        if buf.len() > MAX_HEADER {
            return None;
        }
        let n = stream.read(&mut tmp).ok()?;
        if n == 0 {
            return None;
        }
        buf.extend_from_slice(&tmp[..n]);
    };
    let head = String::from_utf8_lossy(&buf[..head_end]).into_owned();
    let mut lines = head.split("\r\n");
    let mut first = lines.next()?.split_whitespace();
    let method = first.next()?.to_uppercase();
    let target = first.next()?;
    let (path, qs) = target.split_once('?').unwrap_or((target, ""));

    let mut content_len = 0usize;
    let mut cookies = vec![];
    let mut host = String::from("localhost");
    let mut proto = String::from("http");
    for l in lines {
        if let Some((k, v)) = l.split_once(':') {
            let v = v.trim();
            match k.trim().to_ascii_lowercase().as_str() {
                "content-length" => content_len = v.parse().ok()?,
                "host" => host = v.to_string(),
                "x-forwarded-proto" => proto = v.to_string(),
                "cookie" => {
                    for c in v.split(';') {
                        if let Some((ck, cv)) = c.trim().split_once('=') {
                            cookies.push((ck.to_string(), cv.to_string()));
                        }
                    }
                }
                _ => {}
            }
        }
    }
    if content_len > MAX_BODY {
        return None;
    }
    let mut body: Vec<u8> = buf[head_end + 4..].to_vec();
    while body.len() < content_len {
        let n = stream.read(&mut tmp).ok()?;
        if n == 0 {
            return None;
        }
        body.extend_from_slice(&tmp[..n]);
    }
    body.truncate(content_len);
    let form = if method == "POST" { parse_pairs(&String::from_utf8_lossy(&body)) } else { vec![] };
    Some(Req {
        method,
        path: url_decode(path),
        query: parse_pairs(qs),
        form,
        cookies,
        host,
        proto,
    })
}

fn reason(s: u16) -> &'static str {
    match s {
        200 => "OK",
        303 => "See Other",
        400 => "Bad Request",
        404 => "Not Found",
        500 => "Internal Server Error",
        _ => "OK",
    }
}

pub fn write_response(stream: &mut TcpStream, r: &Resp) {
    let mut head = format!(
        "HTTP/1.1 {} {}\r\nContent-Type: {}\r\nContent-Length: {}\r\nConnection: close\r\n\
         X-Content-Type-Options: nosniff\r\nX-Frame-Options: DENY\r\nReferrer-Policy: same-origin\r\n\
         Content-Security-Policy: default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; form-action 'self'; frame-ancestors 'none'\r\n",
        r.status,
        reason(r.status),
        r.ctype,
        r.body.len()
    );
    if !r.headers.iter().any(|(k, _)| k == "Cache-Control") {
        head.push_str("Cache-Control: no-store\r\n");
    }
    for (k, v) in &r.headers {
        head.push_str(&format!("{}: {}\r\n", k, v));
    }
    head.push_str("\r\n");
    let _ = stream.write_all(head.as_bytes());
    let _ = stream.write_all(&r.body);
    let _ = stream.flush();
}

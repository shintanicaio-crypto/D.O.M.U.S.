# D.O.M.U.S. – Smart Fleet Manager (100% Rust)

Frontend e backend escritos em **Rust**, usando apenas a biblioteca padrão (zero dependências externas).
As telas são geradas pelo próprio Rust (`src/views.rs`) e entregues como HTML renderizado no servidor — não há JavaScript.

## Como rodar

```bash
cargo run --release        # Rust 1.75+ ; abre em http://127.0.0.1:3000
```

Login de demonstração: `robertao@email.com` / `domus123`

Variáveis de ambiente (opcionais):

| Variável | Padrão | Função |
|---|---|---|
| `PORT` | `3000` | porta |
| `DOMUS_BIND` | `127.0.0.1` | endereço (use `0.0.0.0` para acessar de outro aparelho) |
| `DOMUS_DATA` | `data` | pasta do banco (`db.txt`) e da chave de sessão (`secret.key`) |
| `DOMUS_SECRET` | gerada | chave para assinar sessões |
| `DOMUS_TZ_OFFSET_HOURS` | `-3` | fuso horário (saudação e datas) |

## Estrutura

```
Cargo.toml
src/main.rs     rotas, regras de negócio, sessões (cookie assinado com HMAC-SHA256)
src/http.rs     servidor HTTP/1.1 sobre std::net
src/crypto.rs   SHA-256, HMAC, PBKDF2 (com testes dos vetores oficiais)
src/store.rs    modelos, dados iniciais e persistência em arquivo
src/views.rs    todas as telas do Figma
static/         styles.css (design system) e extra.css (ajustes sem JS)
```

`cargo test` roda os testes de criptografia.

## Telas

Login/biometria · Entrar com e-mail · Cadastro · Redefinir senha · Home · Alertas e manutenção (abas) ·
Perfil + Família · Convidar (QR) · Cômodos · Frota · Novo robô · Detalhe do robô · Missões (cronograma) · Nova missão.
Navegação inferior fixa: Casa, Cômodos, Frota, Missões, Perfil.

## Decisões e limitações

- **Por que não WebAssembly?** Um frontend Rust no navegador (Yew/Leptos) exige baixar crates e o alvo `wasm32`,
  o que não era possível no ambiente de criação. A solução é renderizar no servidor.
- **Biometria simulada**: o botão de digital autentica o usuário que já tem biometria cadastrada (em produção: WebAuthn).
- **QR Code decorativo**: o desenho vem do link, mas **não é escaneável**. O link do convite aparece num campo para copiar.
  Para um QR real, adicione a crate `qrcode` e troque `views::qr_svg`.
- **Login Google/Apple** e **e-mail de redefinição de senha** não estão integrados.
- Sem HTTPS próprio: em produção, coloque atrás de um proxy com TLS (e adicione `Secure` ao cookie).
- Dados dos robôs (progresso, bateria) são estáticos; não há conexão com hardware.
- Interações que antes usavam JS agora são formulários/links: seleção de manutenção (CSS `:has`), edição inline (`<details>`),
  avisos que somem sozinhos (animação CSS).

## Fluxograma

![alt text](Fluxograma-1.jpeg)